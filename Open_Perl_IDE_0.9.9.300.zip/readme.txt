Open Perl IDE
Copyright � 2001 J�rgen G�ntherodt, All Rights Reserved
e-mail: jguentherodt@users.sourceforge.net
--------------------------------------------------------------------------------

Version 0.9.9
--------------------------------------------------------------------------------

OVERVIEW
-Introduction
-Files
-Requirements 
-Installation Notes
-License
-Disclaimer
--------------------------------------------------------------------------------

INTRODUCTION

Open Perl IDE is an integrated development environment for writing and debugging 
Perl scripts with any standard perl distribution under Windows 95/98/NT/2000.

For the latest news visit our websites 
http://open-perl-ide.sourceforge.net or http://www.lost-sunglasses.de
--------------------------------------------------------------------------------

FILES

The following files are included:
HelloWorld.pl			Tutorial
history.txt		  	Version history
Open_Perl_IDE_Source_*.zip 	Source Code
Open_Perl_IDE_UserManual_*.zip	User Manual in HTML format
PerlIDE.exe		  	The windows executable (Win95/98/NT/2000)
readme.txt		  	This file
--------------------------------------------------------------------------------

REQUIREMENTS

-A proper installed COM Object which implements the IWebBrowser2 interface.
The easiest way to get this, is the installation of MSIE 4 or higher.

-A proper installed standard perl distribution. 
Of course, it is always possible to write nice perl scripts with Open Perl IDE, 
but if you want to run or debug these scripts, then you must have a standard perl 
distribution installed. 


SourceCode Compilation Instructions

1.) Use Delphi 5
This program is compiled with Delphi 5.

2.) Install TDockPanel
Open Perl IDE can not be compiled without a proper installed TDockPanel 
component, located in <source-dir>\components\DockPanel.pas.

3.) Install external packages: SynEdit and Eldos
Furthermore, the following external packages are required:
-SynEdit components for SourceCode Editor and Perl SyntaxColoring, 
visit http://synedit.sourceforge.net
-EldoS ElTree Lite package for an enhanced TreeView, used in debug watch tree 
and other debug windows, visit http://www.eldos.org/elpack/eltree.html
--------------------------------------------------------------------------------

INSTALLATION NOTES

-It is strongly recommended to install Open Perl IDE in it's own directory ! 
-If the PATH environment variable contains a path to perl.exe, then Open Perl IDE 
uses this path. You can set/change this path in the Preferences|General-Tabsheet.
--------------------------------------------------------------------------------

LICENSE

Open Perl IDE is OpenSource under Mozilla Public License 1.1 (the "License").
You may obtain a copy of the License at http://www.mozilla.org/MPL/
--------------------------------------------------------------------------------

DISCLAIMER

THE SOFTWARE IS PROVIDED UNDER THIS LICENSE ON AN "AS IS'' 
BASIS, WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR 
IMPLIED, INCLUDING, WITHOUT LIMITATION, WARRANTIES THAT THE 
SOFTWARE IS FREE OF DEFECTS, MERCHANTABLE, FIT FOR A 
PARTICULAR PURPOSE OR NON-INFRINGING. THE ENTIRE RISK AS TO 
THE QUALITY AND PERFORMANCE OF THE SOFTWARE IS WITH YOU. 
SHOULD THE SOFTWARE PROVE DEFECTIVE IN ANY RESPECT, YOU (NOT 
THE INITIAL DEVELOPER OR ANY OTHER CONTRIBUTOR) ASSUME THE 
COST OF ANY NECESSARY SERVICING, REPAIR OR CORRECTION. THIS 
DISCLAIMER OF WARRANTY CONSTITUTES AN ESSENTIAL PART OF 
THIS LICENSE. NO USE OF THE SOFTWARE IS AUTHORIZED HEREUNDER 
EXCEPT UNDER THIS DISCLAIMER.
--------------------------------------------------------------------------------
